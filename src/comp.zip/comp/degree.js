import React from 'react';

class Degree extends React.Component{
    render(){
        return(
        		<div className="Degree">
					<select name="degree" class="runningtext container">
	                    <option value="Any">Any</option>
	                    <option value="BTech">BTech</option>
	                    <option value="MBA">MBA</option>
	                </select>
                </div>
            );
    }
}

export default Degree;